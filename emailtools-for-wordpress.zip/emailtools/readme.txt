=== emailtools for WordPress ===
Stable tag:        1.0
Tested up to:      7.3
Requires at least: 4.0
Requires PHP:      5.6
Contributors:      dvcheryukin
Donate link:       http://example.com/
Tags:              email, email triggers, email campaign
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html
WC requires at least: 3.0
WC tested up to:      5.4.1

Плагин автоматической интеграции триггерных рассылок.

Here is a short description of the plugin. This should be no more than 150 characters. No markup here.
Emailtools plugin for WordPress
== Description ==
Плагин автоматической интеграции интернет-магазина на Woocommerce с сервисом брошенных корзин и триггерных рассылок https://emailtools.ru

Email-рассылки для забытых корзин, брошенных категори, брошенных товаров, брошенных категорий, брошенных оплат и прочих триггеров.

Реанимируем потенциальных покупателей, которые добавили товар в корзину, но не оформили заказ.

Возвращаем до 80% потерянной прибыли.